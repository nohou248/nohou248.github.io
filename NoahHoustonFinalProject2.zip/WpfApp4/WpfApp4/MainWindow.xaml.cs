﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public static GameApp gameApp = new GameApp();

        public static Inventory inventory = new Inventory();


        public MainWindow()
        {
            InitializeComponent();
            MyContentFrame.Navigate(new Page1());
        }

        public void NameUpdate()
        {         
            UserNameLabel.Content = $"Player name: {gameApp.CurrentPlayer.Name}.";

        }

        public void CountMaterials()
        {
            int materialNumber = gameApp.CurrentPlayer.Materials.Count;
        }



        private void MapButton_Click(object sender, RoutedEventArgs e)
        {
            // Uri mapUri = new Uri("Map.xaml", UriKind.Relative);
            // NavigationService.Navigate(mapUri);
            MyContentFrame.Navigate(new LandList());
        }

        private void InventoryButton_Click(object sender, RoutedEventArgs e)
        {
            MyContentFrame.Navigate(new Inventory());
        }
    }
}
