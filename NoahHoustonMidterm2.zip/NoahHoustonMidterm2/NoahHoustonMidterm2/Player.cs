﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoahHoustonMidterm2
{
    public class Player
    {
        public string Name { get; set; } = "Player Name";


        public List<Ingredient> Inventory { get; set; } = new List<Ingredient>();



        public void CollectIngredient(Ingredient Ingredients)
        {

            if (Inventory.Contains(Ingredients))
            {
                Console.WriteLine($"Looks like you already have this item {Ingredients.Name} in your inventory");
            }
            else
            {
                Inventory.Add(Ingredients);
                Console.WriteLine($"You add {Ingredients.Name} to your inventory");
            }

        }


    }
}
