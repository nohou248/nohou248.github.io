﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NoahHoustonMidterm2
{
    public class Game
    {




        Player player = new Player();

        List<Area> Areas = new List<Area>();





        public Game()
        {



            Ingredient fruit1 = new Ingredient("Red Fruit");
            Ingredient fruit2 = new Ingredient("Blue Fruit");
            Ingredient veg1 = new Ingredient("Blue Vegetable");
            Ingredient veg2 = new Ingredient("Red Vegetable");
            Ingredient pepper = new Ingredient("Spicy Pepper");
            Ingredient pepper2 = new Ingredient("Sweet Pepper");



            Area forest = new Area()
            {
                Name = "Forest Brush",
                Description = "A forest with thick and lush foliage, you may be able to find something here. ",
                Ingredients = { veg1 }
            };
            Areas.Add(forest);

            Area fruitFair = new Area()
            {
                Name = "Fruit Fair",
                Description = "A fruit fair offering some fruit.",
                Ingredients = { fruit1, fruit2, },

            };

            Areas.Add(fruitFair);

            Area cave = new Area()
            {
                Name = "Dark Cave",
                Description = "A dark moist cave that may offer a hidden ingredient.",
                Ingredients = { veg2 }
            };
            Areas.Add(cave);

            Area orchard = new Area()
            {
                Name = "Old Farmer's Orchard",
                Description = "Sneak onto a pepper farmer's orchard!",
                Ingredients = { pepper, pepper2 }
            };
            Areas.Add(orchard);






        }

        public void Start()
        {
            //title screen

            TitleScreen.Title();
            ConsoleCommands.WaitForKey();
            ShowAreas();

            //if playerInventory = 8
            //  then ShowKitchen();
        }








        public void EndScreens()
        {
            if (player.Inventory.Count >= 6)
            {
                Console.Clear();

                {
                    EndScreen.SoupEnd();

                }

            }
            else
            {


            }
        }











        public void ShowAreas()
        {
            Console.Clear();
            EndScreens();
            List<string> areaList = new List<string>();
            foreach (var area in Areas)
            {
                string areaTitle = $"{area.Name}: {area.Description}";
                areaList.Add(areaTitle);

            }


            areaList.Add("Check ingredient count!");

            int areaIndex = ConsoleCommands.ShowMenu(areaList);

            if (areaIndex < Areas.Count)
            {
                MoveAreas(Areas[areaIndex]);
            }
            else
            {
                Console.Clear();
                InventoryCount();
            }

        }








        public void InventoryCount()
        {
            Console.WriteLine($"You've collected {player.Inventory.Count} ingredients so far.");
            Console.WriteLine("Press any key to go back.");
            Console.ReadLine();

            ShowAreas();

        }











        public void MoveAreas(Area area)
        {
            Console.Clear();



            Console.WriteLine($"You are now in: {area.Name}. Here are the ingredients you can scavange here:");

            List<string> ingredientList = new List<string>();

            foreach (var Ingredients in area.Ingredients)
            {
                ingredientList.Add(Ingredients.Name);
            }

            ingredientList.Add("Go back!");

            int IngredientsIndex = ConsoleCommands.ShowMenu(ingredientList);

            if (IngredientsIndex < area.Ingredients.Count)
            {
                player.CollectIngredient(area.Ingredients[IngredientsIndex]);

                Thread.Sleep(1000);

                MoveAreas(area);
            }
            else
            {
                Console.Clear();
                ShowAreas();
            }









        }

    }

}

    


