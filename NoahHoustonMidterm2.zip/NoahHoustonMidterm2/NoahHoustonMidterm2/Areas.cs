﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoahHoustonMidterm2
{
    internal class Areas
    {

        protected Game MyGame;




        public Areas(Game game)
        {
            MyGame = game;

        }

        public class Area
        {
            public string Name { get; set; }



            public string Description { get; set; }



            public List<Ingredient> Items { get; set; } = new List<Ingredient>();
          




        }
    }
}

