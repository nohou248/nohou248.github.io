﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoahHoustonMidterm2
{
    internal class EndScreen : Areas
    {
        public EndScreen(Game game) : base(game)
        {
        }

        public static void SoupEnd()
        {



            //ASCII Text from https://ascii.co.uk/art/bowl
            Console.WriteLine(@"⠀⠀⠀
       ) ))
      ( ((  /)
     ,-===-//
    |`-===-'|
    '       '
     \_____/
gpyy `-----'
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
            Console.Title = "You did it!!";

            Console.WriteLine("You found all the ingredients and made some delicious soup. Good job!!!");
            ConsoleCommands.Exit();


        }
    }
}
