﻿using System;

namespace NoahHoustonMidterm2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();

            game.Start();

            Console.ReadLine();
        }
    }
}