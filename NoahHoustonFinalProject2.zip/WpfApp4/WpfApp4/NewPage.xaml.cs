﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for NewPage.xaml
    /// </summary>
    public partial class NewPage : Page
    {

        GameApp gameApp = MainWindow.gameApp;
        public NewPage()
        {
            InitializeComponent();
        }

       

        private void ToMapButton_Click(object sender, RoutedEventArgs e)
        {
            gameApp.CurrentPlayer.Name = PlayerNameTextBox.Text;
            ((MainWindow)Application.Current.MainWindow).NameUpdate();

            Uri landListUri = new Uri("LandList.xaml", UriKind.Relative);
            NavigationService.Navigate(landListUri);

            


        }

        private void PlayerNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


    }
}
