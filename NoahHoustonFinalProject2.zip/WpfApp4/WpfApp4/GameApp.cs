﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp4
{
    public class GameApp
    {
        public Player CurrentPlayer { get; set; } = new Player();
        public List<Land> Lands { get; set; } = new List<Land>();

        public Land SelectedLand { get; set; }



        public GameApp()
        {
            Land forestLand = new Land()
            {
                Name = "Forest",
                Description = "You will need wood to build your boat. You chop down a few trees and bundle the wood up. Collect materials now!",
                Picture = "forest1-min.jpg",
                Materials = "wood",
            };
            Lands.Add(forestLand);

            Land caveLand = new Land()
            {
                Name = "Cave",
                Description = "You need some stone from the caves to give the ship a stronger structure. You gather some stone! Collect materials now!",
                Picture = "cave1-min.jpg",
                Materials = "stone"
            };
            Lands.Add(caveLand);

            Land cityLand = new Land()
            {
                Name = "City",
                Description = "You have almost everything you need, except for an outfit. You head into a costume shop and buy a hat! Collect materials now!",
                Picture = "city1-min.jpg",
                Materials = "pirate hat"
            };
            Lands.Add(cityLand);
        }
    }
}
