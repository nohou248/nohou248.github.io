﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace NoahHoustonMidterm2
{
    public static class ConsoleCommands
    {

        public static void WaitForKey()
        {          
            WriteLine("Press any key to continue.");
                   ReadKey();
               }

        public static void Exit()
        {
            WriteLine("Press any key to exit.");
            ReadKey(true);
            Environment.Exit(0);
        }
        public static int ShowMenu(List<string> choices)
        {
            int result = -1;
            Console.WriteLine($"(Enter a number to select the option.)");
            for (int i = 0; i < choices.Count; i++)
            {
                int indexLabel = i + 1;
                string choiceLabel = $"{indexLabel}) {choices[i]}";
                Console.WriteLine(choiceLabel);
            }
            try
            {
                result = int.Parse(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }
            if (result >= 1 && result <= choices.Count)
            {
                result--;
                return result;
            }
            else
            {
                return ShowMenu(choices);
            }
        }
    }
}
