﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for LandList.xaml
    /// </summary>
    public partial class LandList : Page
    {


        GameApp gameApp = MainWindow.gameApp;
        public LandList()
        {
            InitializeComponent();
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Image image = (Image)sender;

            gameApp.SelectedLand = gameApp.Lands.First(x => x.Name == image.Tag.ToString());  



            Uri landPageUri = new Uri("LandPage.xaml", UriKind.Relative);
            NavigationService.Navigate(landPageUri);
        }

        private void SeaImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).CountMaterials();

            if (gameApp.CurrentPlayer.Materials.Count >= 3)
            {
                Uri endPageUri = new Uri("endPage.xaml", UriKind.Relative);
                NavigationService.Navigate(endPageUri);
            }
            else
            {
                MessageBox.Show("You need to collect more materials before you can embark!");
            }

        }
    }
}
