﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for LandPage.xaml
    /// </summary>
    public partial class LandPage : Page
    { 

        GameApp gameApp = MainWindow.gameApp;
        Inventory inventory = MainWindow.inventory;

        public LandPage()
        {
            InitializeComponent();

            Land land = gameApp.SelectedLand;

            //MaterialLabel.Visibility = Visibility.Hidden;

            LandNameLabel.Content = $"You are now in the {land.Name}!";

            LandDescriptionLabel.Text =land.Description;

            //MaterialLabel.Content = $"You got: {land.Materials}!";


            

            string imageUri = $"/Resources/{land.Picture}";

            LandPicture.Source = new BitmapImage(new Uri(imageUri, UriKind.Relative));
        }
         
        
        private void MaterialsButton_Click(object sender, RoutedEventArgs e)
        {
            
            Land land = gameApp.SelectedLand;

            MessageBox.Show($"You collected {land.Materials}!");
            if (!gameApp.CurrentPlayer.Materials.Contains(land))
            {
                gameApp.CurrentPlayer.Materials.Add(land);
            }

            ((MainWindow)Application.Current.MainWindow).CountMaterials();



            //inventory.InvVis();

            //((MainWindow)Application.Current.MainWindow).NameUpdate();

            //MaterialLabel.Visibility = Visibility.Visible;

        }
    }
}
