﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoahHoustonMidterm2
{
    internal class TitleScreen : Areas
    {
        public TitleScreen(Game game) : base(game)
        {
        }

        public static void Title()
        {



            //ASCII Text from https://textkool.com
            Console.WriteLine(@"███████  ██████  ██    ██ ██████       ██████   █████  ███    ███ ███████ ██ 
██      ██    ██ ██    ██ ██   ██     ██       ██   ██ ████  ████ ██      ██ 
███████ ██    ██ ██    ██ ██████      ██   ███ ███████ ██ ████ ██ █████   ██ 
     ██ ██    ██ ██    ██ ██          ██    ██ ██   ██ ██  ██  ██ ██         
███████  ██████   ██████  ██           ██████  ██   ██ ██      ██ ███████ ██ 
                                                                             
                                                                             ");
            Console.Title = "Search For Ingredients!";

            Console.WriteLine("You are a chef searching for ingredients in a lush forest for some soup.");
            Console.WriteLine("Find 6 different ingredients to be able to return home and cook!");


        }
    }
}
